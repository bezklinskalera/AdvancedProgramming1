# sampleMavenProject
Simple Maven project template to be used as a start for Maven Java projects.

It has a very simple structure with a folder src/main/java for source code Java files and a folder src/test/java for JUnit test files. The present files, App.java and TestApp.java are there for the folders of the project to be properly cloned from the remote repository. They should be deleted.

Remember to change the artifact id and, if required, the source and target Java version in file pom.xml.
