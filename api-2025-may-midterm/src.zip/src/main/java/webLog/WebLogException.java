package webLog;

public class WebLogException extends RuntimeException {

    public WebLogException() {
    }

    public WebLogException(String message) {
        super(message);
    }
}
